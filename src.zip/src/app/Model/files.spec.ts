import { Files } from './files';

describe('Files', () => {
  it('should create an instance', () => {
    expect(new Files()).toBeTruthy();
  });
});
