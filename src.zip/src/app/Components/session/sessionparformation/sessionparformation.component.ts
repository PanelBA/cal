import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Session} from '../../../Model/Session';
import {SessionService} from '../../../Service/session.service';
import {Seance} from '../../../Model/Seance';
import {SeanceService} from '../../../Service/seance.service';
import {Salle} from '../../../Model/Salle';
import {SpecialiteService} from '../../../Service/specialite.service';
import {Specilaite} from '../../../Model/Specilaite';
import {SalleService} from '../../../Service/salle.service';
import {Inscrir} from '../../../Model/Inscrir';
import {InscrirService} from '../../../Service/inscrir.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {Formateur} from '../../../Model/Formateur';
import {Formation} from '../../../Model/Formation';
import {FormateurService} from '../../../Service/formateur.service';
import {Fraix} from '../../../Model/Fraix';
import {FraixService} from '../../../Service/fraix.service';
import {Planing} from '../../../Model/Planing';
import {PlaningService} from '../../../Service/planing.service';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-sessionparformation',
  templateUrl: './sessionparformation.component.html',
  styleUrls: ['./sessionparformation.component.scss']
})
export class SessionparformationComponent implements OnInit {
  dropdownList = [];
  selectedItems = [];
  dropdownSettings :IDropdownSettings  = {};



  onItemSelect(item: any) {



}
  onSelectAll(items: any) {

  }

 onItemDeSelect(item:any)
{

}
 onDeSelectAll(items:any)
{
}
lstseance  :Seance [] = new Array();
sceance :Seance =new Seance() ;
  sub;
    id ;
    session :Session =new Session();
    seanceajout :Seance =new Seance();
  listeparticipant: Inscrir[] = new Array();
  listplaning :Planing [] = new Array();
salles :Salle []=new Array();
  inscrir :Inscrir=new Inscrir();
  constructor(private  specialiteService:SpecialiteService ,private planingservice :PlaningService ,private fraisservice :FraixService ,  private formateurservice :FormateurService ,  private modalService: NgbModal ,config: NgbModalConfig  , private _Activatedroute:ActivatedRoute, private router: Router,private salleservice :SalleService , private seanceservice :SeanceService ,  private sessionservice :SessionService , private inscrirservice :InscrirService)
  {
   config.backdrop = 'static';
    config.keyboard = false;

  }
formation :Formation=new Formation() ;
formateur: Formateur[] = new Array();
listefraix :Fraix[]=new Array();
seance:Seance=new Seance() ;
salle:Salle=new Salle() ;
planing :Planing =new Planing() ;
fraix :Fraix =new Fraix();
fr : Fraix =new Fraix() ;




  open(content) {
    this.modalService.open(content);
  }
 formateurchoisir  :number  ;
  openfraix(fraix , id : number ) {
    this.modalService.open(fraix);
    this.formateurchoisir =id ;
  }

addfraix()
{
 for(let i=0; i < this.selectedItems.length; i++) {
this.fraisservice.add(this.fr, this.id ,this.selectedItems[i].item_id).subscribe(data => {

      }, error => console.log(error));
}

}


 openlisteformateur(lstfr) {
    this.modalService.open(lstfr);
  }

  openseance(seance) {
    this.modalService.open(seance);
  }


fraixselct : Fraix=new Fraix()  ;
  openfraixF(modiffraix, id:number){
     this.modalService.open(modiffraix);
    this.fraisservice.getbyFormateursession(id,this.id).subscribe(data => {
    this.fraixselct=data ;
        console.log(data)
      }, error => console.log(error));

  }

  modifierfraix(fraixselct)
  {

  this.fraisservice.update(fraixselct).subscribe(data => {

        console.log(data)
      }, error => console.log(error));


  }

 intitule :String ;
ngOnInit() {


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.sessionservice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.session = data;
      }, error => console.log(error));

    this.sessionservice.getintituleFormation(this.id).subscribe(data => {
        console.log(data)
            let tmp = [];
        this.specialiteService.getformateurs(data.categorie).subscribe((data: any) => {
          for(let i=0; i < data.length; i++) {
        tmp.push({ item_id: data[i].id , item_text: data[i].nom+""+data[i].prenom+""+data[i].telephone+""+data[i].adresse   });
      }
      this.dropdownList = tmp;
       });
      }, error => console.log(error));



       this.selectedItems = [

    ];

 this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };





               this.inscrirservice.getSessionParticipant(this.id)
      .subscribe(data => {
        console.log(data)
      }, error => console.log(error));


      });

   this.fraisservice.getbysession(this.id).subscribe(data => {
        console.log(data)
        this.listefraix = data;
      }, error => console.log(error));



      this.salleservice.getAll().subscribe(data => {
        console.log(data)
        this.salles = data;
      }, error => console.log(error));

  this.seanceservice.getAll().subscribe(data => {
        console.log(data)
        this.lstseance = data;
        console.log(data) ;
      }, error => console.log(error));


    this.getAll();

 this.getin();

 this.getsn() ;



      }

   getsn()
   {


   this.planingservice.getplaning(this.id).subscribe(data => {
        console.log(data)
        this.listplaning = data;
      }, error => console.log(error));
   }
  testparticipant :boolean =false ;
      getin()
      {
         this.sessionservice.getInscrir(this.id).subscribe(data => {
        console.log(data)
        this.listeparticipant = data;
        if(this.listeparticipant.length>=10)
        {
        this.testparticipant=true ;
          }else
          {
             this.testparticipant=false ;
          }
      }, error => console.log(error));
      }


affectparticipant(inscrir :Inscrir)
{
this.sessionservice.addparticipant(inscrir, this.session.idsession).subscribe(data => {
   this.getin();
      }, error => console.log(error));



}
  listeocuppe :Salle[] =new Array() ;
 test : boolean ;
 test1 : boolean ;
   message :String="" ;
   message1 :String="" ;
ajouterplaning(planing :Planing)
{  this.test =false ;
   this.test1 =true ;
    this.planingservice.getsalleoccuppe(this.planing.date,this.planing.seance.idseance,planing.salle.idsalle).subscribe(data => {
     console.log(data) ;
     this.test1 =data;
}, error => console.log(error));

  if(this.session.nombrepartcipant > this.planing.salle.capacitesalle)
{
this.test=false ;
this.message  =this.message +" Deppassement de capacité de salle" ;
}

if((this.test=true)&&(this.test1=true))
{
this.planingservice.add(planing,this.id,1,planing.salle.idsalle).subscribe(data => {
this. getsn() ;
}, error => console.log(error));
}
else {
this.message="eraaah";
}
}
private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}


    deleteinscrir(id : number)
    {

    this.sessionservice.deleteinscrir(this.session.idsession ,id).subscribe(data => {
   this.getin();

    }, ex => {
      console.log(ex);
    });

    }
inscrirmodif :Inscrir =new Inscrir();
updateinscrir(modifinscri ,f :Inscrir)
{
 this.modalService.open(modifinscri);
this.sessionservice.getinscrirbyid(f.id).subscribe(data => {
   this.inscrirmodif=data;

    }, ex => {
      console.log(ex);
    });

}



}
