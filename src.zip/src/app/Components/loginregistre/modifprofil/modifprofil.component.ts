import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifprofil',
  templateUrl: './modifprofil.component.html',
  styleUrls: ['./modifprofil.component.scss']
})
export class ModifprofilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
