import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetatilsformateurComponent } from './detatilsformateur.component';

describe('DetatilsformateurComponent', () => {
  let component: DetatilsformateurComponent;
  let fixture: ComponentFixture<DetatilsformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetatilsformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetatilsformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
