import { Component, OnInit, OnDestroy  } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ListformateurComponent } from '../listformateur/listformateur.component';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {FormControl,FormGroup,FormBuilder,Validators, NgControl,ValidationErrors } from '@angular/forms';
import { HttpClient, HttpEventType } from '@angular/common/http';
import {FileService} from '../../../Service/file.service';
@Component({
  selector: 'app-detatilsformateur',
  templateUrl: './detatilsformateur.component.html',
  styleUrls: ['./detatilsformateur.component.scss']
})
export class DetatilsformateurComponent implements OnInit {

  constructor(private httpClient: HttpClient , private FileService :FileService ,private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService ) { }
   sub;
    id ;
     selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  imageName: any;

     formateur : Formateur ;

 ngOnInit() {

      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formateurService.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formateur = data;
      }, error => console.log(error));

      });


      this.getImage();









   }

   ngOnDestroy() {
     this.sub.unsubscribe();
   }

   getImage() {
    //Make a call to Sprinf Boot to get the Image Bytes.
    this.httpClient.get('http://localhost:9028/getCertificatformateur/' + this.id)
      .subscribe(
        res => {
          this.retrieveResonse = res;
          this.base64Data = this.retrieveResonse.picByte;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
        }
      );
  }




}

