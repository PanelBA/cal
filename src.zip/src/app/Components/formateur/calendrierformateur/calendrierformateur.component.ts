import { Component, OnInit , ViewChild  } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { ListformateurComponent } from '../listformateur/listformateur.component';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {MatDialog, MatDialogConfig} from "@angular/material/dialog";

import { CalendarOptions } from '@fullcalendar/angular'; // useful for typechecking



@Component({
  selector: 'app-calendrierformateur',
  templateUrl: './calendrierformateur.component.html',
  styleUrls: ['./calendrierformateur.component.scss']
})
export class CalendrierformateurComponent implements OnInit {
 sub;
    id ;
   formateur : Formateur ;
constructor( private dialog: MatDialog , private modalService: NgbModal ,config: NgbModalConfig  , private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService)
  {}

  ngOnInit() {

  }

calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
     dateClick: this.handleDateClick.bind(this), // bind is important!
    events: [
      { title: 'event 1', date: '2019-04-01' },
      { title: 'event 2', date: '2019-04-02' },
    ]


  };

  handleDateClick(arg) {
    alert('date click! ' + arg.dateStr)
  }


}

