import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccplateformeComponent } from './accplateforme/accplateforme.component';

const routes: Routes = [

    { path: 'accui', component: AccplateformeComponent },



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
